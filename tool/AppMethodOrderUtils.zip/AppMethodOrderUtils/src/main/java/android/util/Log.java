package android.util;

public class Log {
    public static void d(String tag, String s) {
    }

    public static void w(String tag, String s, RuntimeException e) {
    }
}
