package AppMethodOrderUtils;

import java.io.*;
import java.util.*;

/**
 * 文件扫描
 */
public class TraceScanner {
    private File file;
    private String packageName = "";
    private TraceScanner.AnalysisListener listener;

    public TraceScanner(File file) {
        super();
        this.file = file;
        System.out.println("file：" + file);
    }

    public void setFile(File file) {
        this.file = file;
    }

    public void setPackageName(String packageName) {
        this.packageName = packageName;
    }

    public void setListener(AnalysisListener listener) {
        this.listener = listener;
    }

    public ArrayList<OrderBean> convertFile(String path) {
        ArrayList<String> index = new ArrayList<String>();

        ArrayList<OrderBean> list = new ArrayList<>();

        HashMap<String, String> map = new HashMap<>();
        HashMap<String, Stack<OrderBean>> stackMap = new HashMap<>();


        String osName = System.getProperty("os.name");

        Log.e(Log.getTag(),"packageName：" + packageName);
        index.add("PackageName: " + packageName + "\n");
        index.add("start dmtracedump\n");
        String oName = packageName.replaceAll("[.]", "/");
        if (listener != null) {
            listener.startAnalysis();
        }
        if (!file.exists()) {
            System.out.println("File does not exist");
        } else {
            Runtime runtime = Runtime.getRuntime();
            BufferedReader br = null;
            try {
                Process p;
                if (osName.contains("Windows") || osName.contains("windows")) {
                    p = Runtime.getRuntime().exec(Utils.getWinCommand(path));
                } else {
                    // mac or linux
                    p = Runtime.getRuntime().exec(Utils.getMacCommand(path));
                }

                br = new BufferedReader(new InputStreamReader(
                        p.getInputStream()));
                String lineTxt = null;
                long count = 1;
                boolean canPut = true;
                // 读取每行的数据
                while ((lineTxt = br.readLine()) != null) {
                    OrderBean orderBean = new OrderBean(lineTxt);
                    orderBean.setOrder(count++);
                    if ((lineTxt.contains(" ent ") || lineTxt.contains(" xit "))
                            && (lineTxt.contains(packageName) || lineTxt.contains(oName))) {
                        orderBean.setTimeAndFuction();
                        if (!map.isEmpty()) {
                            for (Map.Entry<String, String> entry : map.entrySet()) {
                                if (entry == null) continue;
                                if (orderBean.getThreadId().equals(entry.getKey())) {
                                    orderBean.setThreadName(entry.getValue());
                                }
                            }
                        }

                        if (lineTxt.contains(" ent ")) {
                            list.add(orderBean);
                            stackMap.get(orderBean.getThreadId()).push(orderBean);
                        } else if (lineTxt.contains(" xit ")) {
                            if (stackMap.get(orderBean.getThreadId()).isEmpty()) {
                                continue;
                            }
                            OrderBean peek = stackMap.get(orderBean.getThreadId()).peek();
                            if (peek.getFunctionName().equals(orderBean.getFunctionName())) {
                                OrderBean pop = stackMap.get(orderBean.getThreadId()).pop();
                                String costTime = "" + Math.abs(Long.parseLong(orderBean.getTime()) - Long.parseLong(pop.getTime()));
                                pop.setCostTime(costTime);
                            }
                        }
                    } else {
                        //Trace信息头不需要解析
                        if (lineTxt.contains("Trace ")) {
                            //完成线程信息的登记
                            if (!map.isEmpty()) {
                                for (Map.Entry<String, String> entry : map.entrySet()) {
                                    if (entry == null) continue;
                                    //按线程生成对应的stack
                                    stackMap.put(entry.getKey(),new Stack<>());
                                }
                            }
                            canPut = false;
                        } else {
                            if (canPut) {
                                //获取线程信息
                                map.put(lineTxt.split(" +", 2)[0].trim(), lineTxt.split(" +", 2)[1].trim());
                            }
                        }
                    }
                }

                Collections.sort(list);

               // if (packageName.equals("")) {
                    outTxt(list, "./appMethodOrderTrace.txt");
                //}
            } catch (Exception e) {
                index.add("执行dmtracedump命令异常\n");
                e.printStackTrace();
            } finally {
                if (br != null) {
                    try {
                        br.close();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                index.add("end dmtracedump\n");
                System.out.println("cmd end");
                if (listener != null) {
                    listener.afterAnalysis();
                }
            }
        }
        return list;

    }

    private static void outTxt(ArrayList<OrderBean> list, String fileName) throws IOException {
        StringBuffer stringBuffer = new StringBuffer();

        for (OrderBean orderBean : list) {
            if (orderBean.isXit()) continue;
            stringBuffer.append(orderBean.getThreadId());
            stringBuffer.append("	");
            stringBuffer.append(orderBean.getThreadName());
            stringBuffer.append("	");
            stringBuffer.append(orderBean.getCostTime());
            stringBuffer.append("	");
            stringBuffer.append(orderBean.getFunctionName());
            stringBuffer.append("\n");
        }

        File file = new File(fileName);
        if (!file.exists()) {
            file.createNewFile();
        }
        FileWriter fileWriter = new FileWriter(fileName);
        fileWriter.write(stringBuffer.toString());
        fileWriter.flush();
        fileWriter.close();
    }
    
    public interface AnalysisListener {
        void startAnalysis();

        void afterAnalysis();
    }

}
